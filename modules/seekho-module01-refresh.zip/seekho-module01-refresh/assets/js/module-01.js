/* Seekho Digital · Module 01 interactions. Progress and drafts stay in this browser. */
(() => {
  'use strict';
  const root = document.querySelector('.m1-page');
  if (!root) return;

  const lessons = [
    {
      tag: 'THE BIG PICTURE', title: 'Marketing is helping the right people find the right value.',
      intro: 'Marketing is not simply posting online or convincing everyone to buy. It is understanding people, offering something useful, explaining its value and making it easier for the right people to choose.',
      blocks: [
        ['callout','Think of it this way','A neighbourhood bakery does not need to attract every person in the city. It needs to help nearby people who enjoy fresh bread discover why this bakery might be right for them.'],
        ['heading','Marketing and advertising are not the same'],
        ['paragraph','Marketing is the wider plan: learning about customers, shaping an offer, choosing a price, communicating value and improving the experience. Advertising is one possible way to pay for attention and promote a message.'],
        ['example','MAPLE LANE EXAMPLE','The bakery asks customers what they enjoy, improves its morning menu, shares useful updates and makes ordering easy. A paid social media ad could support that plan, but it is only one part of it.'],
        ['try','Quick think','Is a helpful Instagram post the whole of marketing?','No. It is one communication activity. Good marketing also includes understanding customers, the offer, the experience and what happens after someone responds.']
      ]
    },
    {
      tag:'THE DIGITAL ECOSYSTEM',title:'Digital marketing is a connected set of ways to help people.',
      intro:'Digital marketing uses digital places and tools to communicate value, make useful experiences easier and learn from the response. A website, search engine, email and social platform can all play different roles.',
      blocks:[
        ['heading','Three useful channel groups'],
        ['paragraph','Owned channels are places a business controls, such as its website, email list or app. Earned attention is exposure others choose to give, such as a genuine customer recommendation or an editorial mention. Paid channels include advertising placements a business pays for.'],
        ['callout','A simple example','Maple Lane owns its website and email list. A happy customer may recommend it in a neighbourhood group (earned). The bakery might also pay to show a local ad (paid).'],
        ['heading','Why use more than one?'],
        ['paragraph','Different people discover and evaluate businesses in different ways. A search result may help someone with an immediate need; a useful social post may introduce the bakery to someone who was not looking yet. The channels should support one clear customer experience—not compete with one another.'],
        ['try','Quick think','Is a business profile on a third-party social platform fully owned by the business?','Not entirely. The business controls the content it posts, but the platform controls its rules, features and access. A website and consent-based email list give the business more direct control.']
      ]
    },
    {
      tag:'UNDERSTAND PEOPLE FIRST',title:'A useful message starts with a real person—not a guess.',
      intro:'An audience is the group of people a business wants to understand and serve. “Everyone” is usually too broad to guide a useful message or channel choice.',
      blocks:[
        ['heading','Build a simple audience picture'],
        ['paragraph','Start with context: where might the person be, what are they trying to do, what gets in their way and what would make a choice easier? Use real conversations, questions, feedback and observed behaviour when available.'],
        ['callout','A beginner-friendly audience description','People who live or work close to Maple Lane, have busy mornings and want a fresh breakfast that is easy to collect. This is more useful than “people who like food”.'],
        ['heading','Need before demographic labels'],
        ['paragraph','Age or location can sometimes matter, but they do not explain everything. A customer need—convenience, confidence, affordability, accessibility or a particular solution—often gives a better starting point. Avoid stereotypes. Check your assumptions with evidence.'],
        ['try','Quick think','Which description gives a stronger starting point?','“Everyone aged 18–60” is broad. “Nearby workers looking for a quick breakfast before 9 am” describes a context and need that can guide a message and offer.']
      ]
    },
    {
      tag:'THE CUSTOMER JOURNEY',title:'People often take several steps before they decide.',
      intro:'A customer journey is the path a person may take as they discover a need, explore options, make a decision and experience what happens next. It is not always a straight line.',
      blocks:[
        ['heading','A simple three-stage model'],
        ['paragraph','Awareness: a person notices a need or discovers a possible solution. Consideration: they compare options, check details and decide what feels right. Decision: they take an action such as enquiring, booking or buying. After the decision, the experience can influence whether they return or recommend the business.'],
        ['example','MAPLE LANE EXAMPLE','Awareness: someone sees a neighbour mention the bakery. Consideration: they check the menu, location and opening times. Decision: they place a breakfast-box order. Experience: collection is smooth, so they may return.'],
        ['callout','Meet people where they are','A person who has never heard of the bakery may need a clear introduction. Someone already checking the menu may need practical details such as price, ingredients and collection time. One message will not fit every stage.'],
        ['try','Quick think','What might help someone in the consideration stage?','Clear menu information, location, prices, opening hours, honest photos and answers to common questions can help someone compare options.']
      ]
    },
    {
      tag:'THE RIGHT WORDS',title:'A channel, a platform and a format mean different things.',
      intro:'These words are related, but they are not interchangeable. Knowing the difference helps you explain a plan clearly and choose the right tool for the job.',
      blocks:[
        ['callout','Remember the three levels','Channel = the route. Platform = the specific service. Format = the shape of the content.'],
        ['heading','One example, three labels'],
        ['paragraph','Social media is a channel. Instagram is a platform. An Instagram Reel is a content format. Another example: email is a channel, an email service is a platform/tool, and a short newsletter is a format.'],
        ['heading','Choose based on the audience and task'],
        ['paragraph','Do not choose a channel only because it is popular. Ask where your audience looks for information, what they need to do and whether you can maintain a helpful, accessible presence there.'],
        ['try','Quick think','In “a YouTube tutorial”, what is the platform?','YouTube is the platform. Video tutorial is the format. The channel is online video or, more broadly, social/video content depending on the plan.']
      ]
    },
    {
      tag:'GOALS THAT GUIDE YOU',title:'A goal gives your marketing a direction.',
      intro:'A clear objective helps you decide what to do and how to judge whether it helped. “Get more popular” is hard to act on. A specific, measurable outcome is easier to learn from.',
      blocks:[
        ['heading','Try the SMART checklist'],
        ['paragraph','Specific: say exactly what should happen. Measurable: decide what number or evidence will show progress. Achievable: keep it realistic for the resources available. Relevant: connect it to a real business need. Time-bound: set a review period.'],
        ['example','MAPLE LANE EXAMPLE','“Receive 20 breakfast-box enquiries from nearby customers over the next 30 days” is more useful than “grow online”. The number is an illustrative practice target, not a real business forecast.'],
        ['callout','A target is a hypothesis, not a guarantee','Choose a reasonable starting target, observe the result and adjust. Marketing outcomes depend on the offer, audience, competition, execution and many factors outside one person’s control.'],
        ['try','Quick think','Which objective is easier to measure?','“Become famous” is vague. “Get 30 menu-page visits from local search over the next month” names an action, a source and a time period.']
      ]
    },
    {
      tag:'MEASURE WHAT MATTERS',title:'A useful metric tells you something about your goal.',
      intro:'A metric is a number used to understand what is happening. Choose it because it helps answer a question—not simply because it looks impressive.',
      blocks:[
        ['heading','A few beginner-friendly metrics'],
        ['paragraph','Reach estimates how many people were exposed to content. Clicks count link taps. Enquiries count people who contact the business. Conversion rate is the share of a defined group that takes the chosen action. Always state what counts, which group is included and the time period.'],
        ['callout','A simple conversion-rate example','If 4 out of 100 menu-page visitors place an order, the conversion rate for that defined action and period is 4%. The number alone does not explain why people did or did not order.'],
        ['heading','Be careful with vanity metrics'],
        ['paragraph','A large view or follower count can be encouraging, but it may not show whether the right people took a meaningful action. Pair attention metrics with measures closer to the business goal, such as qualified enquiries, bookings or repeat customers.'],
        ['try','Quick think','If the goal is to receive more orders, which metric is closer to the goal: likes or completed orders?','Completed orders are closer to the goal. Likes can provide context, but they are not a substitute for the result the business actually wants.']
      ]
    },
    {
      tag:'YOUR FIRST MARKETING BRIEF',title:'Bring the pieces together in one simple plan.',
      intro:'You now have the building blocks: a defined audience, a customer need, a useful message, a suitable channel, a clear objective and a metric. A short brief helps keep those choices connected.',
      blocks:[
        ['heading','The five questions in your project'],
        ['paragraph','Who are you trying to reach? What do they need? What useful message or offer can help? Where can you reach them appropriately? What result will you measure, and over what period?'],
        ['example','MAPLE LANE EXAMPLE','Audience: nearby workers with busy mornings. Need: a convenient fresh breakfast. Message: breakfast boxes prepared locally and ready for collection. Possible channels: local search information and an active social profile. Measure: relevant enquiries or pre-orders over a defined period.'],
        ['callout','Keep your first plan small','One audience, one clear offer, one or two appropriate channels and one meaningful measure are enough for a first experiment. You can learn and improve from there.'],
        ['try','Your next move','Complete the Marketing Brief below. Save a draft on your device or download a copy. Your work is yours to keep.']
      ]
    }
  ];

  const quiz = [
    {q:'What is the best description of marketing?',a:['Posting on social media every day','Understanding people and creating, communicating and delivering value','Running paid advertisements only'],correct:1,why:'Marketing is broader than posting or advertising. It starts with people and value, then connects the offer, communication and experience.'},
    {q:'Which is an example of an owned channel?',a:['A business website it controls','A newspaper article written by someone else','A paid ad placement on another platform'],correct:0,why:'A website the business controls is an owned channel. Earned attention comes from others, while paid placement is advertising.'},
    {q:'Which audience description is more useful?',a:['Everyone on the internet','People who like nice things','Nearby workers who want a quick breakfast before work'],correct:2,why:'The third option includes a context and a need. It gives the business a better starting point for its offer and message.'},
    {q:'Someone checks the bakery menu, prices and opening hours before ordering. Which stage are they most likely in?',a:['Awareness','Consideration','After-purchase advocacy'],correct:1,why:'They have discovered the bakery and are evaluating whether it suits them. That is the consideration stage.'},
    {q:'In “an Instagram Reel”, which word names the platform?',a:['Instagram','Social media','Reel'],correct:0,why:'Instagram is the platform, social media is the channel and a Reel is the content format.'},
    {q:'Which is the clearest measurable objective?',a:['Become the best bakery online','Get more attention soon','Receive 20 breakfast-box enquiries in 30 days'],correct:2,why:'The third objective names an action, a quantity and a time period. The target is an illustrative practice goal, not a guarantee.'},
    {q:'If the goal is more orders, which metric is closest to that goal?',a:['Follower count','Completed orders','Number of colours in a post'],correct:1,why:'Completed orders directly measure the desired action. Other numbers may provide context but are not the final result.'},
    {q:'What should a beginner do before choosing a platform?',a:['Understand the audience and what they need','Copy the biggest competitor','Post on every platform at once'],correct:0,why:'Start with people and the job they need done. Then choose channels that fit the audience, goal and resources.'}
  ];

  const $ = (s) => root.querySelector(s);
  const $$ = (s) => [...root.querySelectorAll(s)];
  const STORAGE_KEY = 'seekho-module-01-v1';
  let completed = [];
  let currentLesson = 0;
  let questionIndex = 0;
  let score = 0;
  let answered = false;

  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    if (Array.isArray(saved.completed)) completed = saved.completed.filter(n => Number.isInteger(n) && n >= 0 && n < lessons.length);
    if (saved.brief && typeof saved.brief === 'object') {
      Object.entries(saved.brief).forEach(([name, value]) => {
        const field = $('#m1-brief [name="' + name + '"]');
        if (field && typeof value === 'string') field.value = value;
      });
    }
  } catch (_) { /* Storage can be unavailable in private/restricted browsing. */ }

  const persist = (extra = {}) => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({completed, ...extra})); }
    catch (_) { /* The lesson still works when storage is blocked. */ }
  };

  const updateProgress = () => {
    const count = completed.length;
    const percent = Math.round(count / lessons.length * 100);
    $('#m1-progress-text').textContent = `${count} of ${lessons.length} lessons completed`;
    $('#m1-progress-percent').textContent = `${percent}%`;
    $('#m1-progress-fill').style.width = `${percent}%`;
    $$('#m1-lesson-nav button').forEach((button, index) => {
      button.classList.toggle('done', completed.includes(index));
      button.setAttribute('aria-current', index === currentLesson ? 'step' : 'false');
    });
    $('#m1-complete').classList.toggle('done', completed.includes(currentLesson));
    $('#m1-complete').textContent = completed.includes(currentLesson) ? 'Lesson completed ✓' : 'Mark lesson complete ✓';
  };

  const escapeHTML = (value) => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const blockHTML = (block, index) => {
    const [type, title, text, answer] = block;
    if (type === 'heading') return `<h4>${escapeHTML(title)}</h4>`;
    if (type === 'paragraph') return `<p>${escapeHTML(title)}</p>`;
    if (type === 'callout') return `<div class="m1-callout"><b>${escapeHTML(title)}</b><p>${escapeHTML(text)}</p></div>`;
    if (type === 'example') return `<div class="m1-example"><span>${escapeHTML(title)}</span><p>${escapeHTML(text)}</p></div>`;
    if (type === 'try') return `<div class="m1-trybox"><b>${escapeHTML(title)}</b><p>${escapeHTML(text)}</p><button type="button" class="m1-reveal" data-reveal="m1-reveal-${index}">Reveal a hint</button><p class="m1-reveal-answer" id="m1-reveal-${index}" hidden>${escapeHTML(answer)}</p></div>`;
    return '';
  };

  const renderLesson = (index) => {
    currentLesson = Math.max(0, Math.min(lessons.length - 1, index));
    const lesson = lessons[currentLesson];
    $('#m1-lesson-number').textContent = `LESSON ${String(currentLesson + 1).padStart(2,'0')} / ${String(lessons.length).padStart(2,'0')}`;
    $('#m1-lesson-tag').textContent = lesson.tag;
    $('#m1-lesson-article').innerHTML = `<h3>${escapeHTML(lesson.title)}</h3><p>${escapeHTML(lesson.intro)}</p>${lesson.blocks.map(blockHTML).join('')}`;
    $$('#m1-lesson-nav button').forEach((button, i) => button.classList.toggle('active', i === currentLesson));
    $('#m1-prev').disabled = currentLesson === 0;
    $('#m1-next').textContent = currentLesson === lessons.length - 1 ? 'Go to project ↓' : 'Next lesson →';
    updateProgress();
    $('#m1-lesson-article').querySelectorAll('[data-reveal]').forEach(button => {
      button.addEventListener('click', () => {
        const panel = document.getElementById(button.dataset.reveal);
        if (!panel) return;
        panel.hidden = !panel.hidden;
        button.textContent = panel.hidden ? 'Reveal a hint' : 'Hide hint';
      });
    });
  };

  $$('#m1-lesson-nav button').forEach(button => button.addEventListener('click', () => renderLesson(Number(button.dataset.lesson))));
  $('#m1-prev').addEventListener('click', () => renderLesson(currentLesson - 1));
  $('#m1-next').addEventListener('click', () => {
    if (currentLesson === lessons.length - 1) $('#project').scrollIntoView({behavior:'smooth'});
    else renderLesson(currentLesson + 1);
  });
  $('#m1-complete').addEventListener('click', () => {
    if (!completed.includes(currentLesson)) completed.push(currentLesson);
    persist();
    updateProgress();
  });

  const renderQuestion = () => {
    const item = quiz[questionIndex];
    answered = false;
    $('#m1-quiz-count').textContent = `QUESTION ${questionIndex + 1} OF ${quiz.length}`;
    $('#m1-quiz-progress').style.width = `${questionIndex / quiz.length * 100}%`;
    $('#m1-question').textContent = item.q;
    $('#m1-feedback').textContent = 'Choose one answer to see why it works.';
    $('#m1-answers').innerHTML = item.a.map((answer, i) => `<button type="button" data-answer="${i}">${escapeHTML(answer)}</button>`).join('');
    $('#m1-quiz-next').disabled = true;
    $('#m1-quiz-next').textContent = questionIndex === quiz.length - 1 ? 'See my result →' : 'Next question →';
    $('#m1-quiz-next').hidden = false;
    $('#m1-quiz-restart').hidden = true;
    $('#m1-quiz-result').hidden = true;
    $$('#m1-answers button').forEach(button => button.addEventListener('click', () => {
      if (answered) return;
      answered = true;
      const choice = Number(button.dataset.answer);
      const correct = choice === item.correct;
      if (correct) score++;
      $$('#m1-answers button').forEach((option, i) => {
        option.disabled = true;
        if (i === item.correct) option.classList.add('correct');
        else if (i === choice) option.classList.add('incorrect');
      });
      $('#m1-feedback').textContent = `${correct ? 'Correct! ' : 'Good try. '}${item.why}`;
      $('#m1-quiz-next').disabled = false;
    }));
  };
  $('#m1-quiz-next').addEventListener('click', () => {
    if (!answered) return;
    if (questionIndex < quiz.length - 1) {
      questionIndex++;
      renderQuestion();
    } else {
      $('#m1-quiz-count').textContent = 'COMPLETE';
      $('#m1-quiz-progress').style.width = '100%';
      $('#m1-question').textContent = 'You made it through the knowledge check.';
      $('#m1-answers').innerHTML = '';
      $('#m1-feedback').textContent = 'Review any lesson you want to strengthen. Learning is a process, not a one-time score.';
      $('#m1-quiz-next').hidden = true;
      $('#m1-quiz-result').hidden = false;
      $('#m1-quiz-result').textContent = `Your result: ${score} / ${quiz.length}. ${score >= 6 ? 'Strong foundation—keep practising and applying it.' : 'Good first attempt. Revisit the lessons and try again when you feel ready.'}`;
      $('#m1-quiz-restart').hidden = false;
    }
  });
  $('#m1-quiz-restart').addEventListener('click', () => { questionIndex = 0; score = 0; renderQuestion(); });

  const form = $('#m1-brief');
  const collectBrief = () => Object.fromEntries(new FormData(form).entries());
  form.addEventListener('submit', (event) => {
    event.preventDefault();
    persist({brief:collectBrief()});
    $('#m1-brief-status').textContent = 'Draft saved on this browser ✓ Download a copy if you want to keep it elsewhere.';
  });
  $('#m1-download-brief').addEventListener('click', () => {
    const labels = {audience:'Target audience',need:'Customer need',message:'Useful message',channels:'Possible channels',metric:'Result to measure'};
    const fields = collectBrief();
    const report = ['SEEKHO DIGITAL · MODULE 01','MAPLE LANE HOME BAKERY · MARKETING BRIEF','',...Object.entries(labels).flatMap(([key,label]) => [`${label}:`,fields[key] || '(Not filled in)','']), 'Practice brief only. Maple Lane Home Bakery is fictional.'].join('\n');
    const blob = new Blob([report], {type:'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = 'seekho-module-01-marketing-brief.txt';
    document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url);
    $('#m1-brief-status').textContent = 'Your project brief download has started.';
  });

  renderLesson(0);
  renderQuestion();
})();
